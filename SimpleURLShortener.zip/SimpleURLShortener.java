import java.util.Scanner;

public class SimpleURLShortener {

    static String[] urls = new String[100];
    static String[] codes = new String[100];
    static int index = 0;

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n1. Shorten URL");
            System.out.println("2. Redirect");
            System.out.println("3. Exit");
            System.out.print("Enter choice: ");

            int choice = sc.nextInt();
            sc.nextLine();

            if (choice == 1) {
                System.out.print("Enter URL: ");
                String url = sc.nextLine();
                String code = shorten(url);
                System.out.println("Short Code: " + code);
            }
            else if (choice == 2) {
                System.out.print("Enter Short Code: ");
                String code = sc.nextLine();
                String url = redirect(code);
                System.out.println("Original URL: " + url);
            }
            else if (choice == 3) {
                break;
            }
            else {
                System.out.println("Invalid Choice");
            }
        }

        sc.close();
    }

    public static String shorten(String url) {
        String code = "C" + index + "X";   // simple short code
        urls[index] = url;
        codes[index] = code;
        index++;
        return code;
    }

    public static String redirect(String code) {
        for (int i = 0; i < index; i++) {
            if (codes[i].equals(code)) {
                return urls[i];
            }
        }
        return "Not Found";
    }
}
