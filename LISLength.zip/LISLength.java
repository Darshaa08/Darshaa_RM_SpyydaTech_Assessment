import java.util.Scanner;

public class LISLength {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter number of elements:");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter elements:");

        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        int length = findLIS(arr, n);
        System.out.println("Output: " + length);

        sc.close();
    }

    public static int findLIS(int[] arr, int n) {

        int[] lis = new int[n];

        for (int i = 0; i < n; i++) {
            lis[i] = 1;  // every element itself is a LIS of length 1
        }

        for (int i = 1; i < n; i++) {
            for (int j = 0; j < i; j++) {
                if (arr[i] > arr[j] && lis[i] < lis[j] + 1) {
                    lis[i] = lis[j] + 1;
                }
            }
        }

        int max = lis[0];
        for (int i = 1; i < n; i++) {
            if (lis[i] > max) {
                max = lis[i];
            }
        }

        return max;
    }
}
