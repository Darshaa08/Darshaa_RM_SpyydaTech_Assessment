import java.util.Scanner;

public class BalancedBrackets {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter bracket sequence:");
        String input = sc.nextLine();   // user input

        boolean result = isBalanced(input);

        if (result) {
            System.out.println("True");
        } else {
            System.out.println("False");
        }

        sc.close();
    }

    public static boolean isBalanced(String s) {

        char[] stack = new char[50];
        int top = -1;

        for (int i = 0; i < s.length(); i++) {

            char ch = s.charAt(i);

            if (ch == '(' || ch == '{' || ch == '[') {
                top++;
                stack[top] = ch;
            }
            else if (ch == ')' || ch == '}' || ch == ']') {

                if (top == -1) return false;

                char open = stack[top];
                top--;

                if ((ch == ')' && open != '(') ||
                    (ch == '}' && open != '{') ||
                    (ch == ']' && open != '[')) {
                    return false;
                }
            }
            else {
                return false; // invalid characters
            }
        }

        return top == -1;
    }
}
