public class WordFrequencySimple {

    public static void main(String[] args) {

        String text = "Hello world hello Spyyda";

        // convert to lowercase manually
        String s = "";
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c >= 'A' && c <= 'Z') {
                c = (char)(c + 32);
            }
            s = s + c;
        }

        // extract words manually
        String[] words = new String[20];
        String temp = "";
        int wc = 0;

        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c != ' ') {
                temp = temp + c;
            } else {
                words[wc] = temp;
                wc++;
                temp = "";
            }
        }
        words[wc] = temp;
        wc++;

        // count word frequencies manually
        String[] unique = new String[20];
        int[] freq = new int[20];
        int uc = 0;

        for (int i = 0; i < wc; i++) {
            boolean found = false;
            for (int j = 0; j < uc; j++) {
                if (unique[j].equals(words[i])) {
                    freq[j]++;
                    found = true;
                    break;
                }
            }
            if (!found) {
                unique[uc] = words[i];
                freq[uc] = 1;
                uc++;
            }
        }

        // print output
        for (int i = 0; i < uc; i++) {
            System.out.println(unique[i] + " - " + freq[i]);
        }
    }
}
