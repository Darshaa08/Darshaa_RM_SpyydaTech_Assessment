import java.util.ArrayList;
import java.util.Scanner;

class Book {
    String id;
    String name;
    boolean available;

    Book(String id, String name, boolean available) {
        this.id = id;
        this.name = name;
        this.available = available;
    }
}

public class LibrarySystem {

    public static void main(String[] args) {

        ArrayList<Book> books = new ArrayList<>();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("----- Library Menu -----");
            System.out.println("1. Add Book");
            System.out.println("2. Search Book");
            System.out.println("3. Borrow Book");
            System.out.println("4. Return Book");
            System.out.println("5. Show All Books");
            System.out.println("6. Exit");
            System.out.println("Enter choice:");

            int choice = sc.nextInt();
            sc.nextLine(); // to clear buffer

            if (choice == 1) {
                System.out.println("Enter Book ID:");
                String id = sc.nextLine();
                System.out.println("Enter Book Name:");
                String name = sc.nextLine();

                books.add(new Book(id, name, true));
                System.out.println("Book Added!");
            }

            else if (choice == 2) {
                System.out.println("Enter Book ID to Search:");
                String id = sc.nextLine();
                boolean found = false;

                for (Book b : books) {
                    if (b.id.equals(id)) {
                        System.out.println("Book Found: " + b.name + "  Available: " + b.available);
                        found = true;
                        break;
                    }
                }

                if (!found) System.out.println("Book Not Found");
            }

            else if (choice == 3) {
                System.out.println("Enter Book ID to Borrow:");
                String id = sc.nextLine();
                boolean found = false;

                for (Book b : books) {
                    if (b.id.equals(id)) {
                        if (b.available) {
                            b.available = false;
                            System.out.println("Borrowed Successfully");
                        } else {
                            System.out.println("Already Borrowed");
                        }
                        found = true;
                        break;
                    }
                }

                if (!found) System.out.println("Book Not Found");
            }

            else if (choice == 4) {
                System.out.println("Enter Book ID to Return:");
                String id = sc.nextLine();
                boolean found = false;

                for (Book b : books) {
                    if (b.id.equals(id)) {
                        b.available = true;
                        System.out.println("Returned Successfully");
                        found = true;
                        break;
                    }
                }

                if (!found) System.out.println("Book Not Found");
            }

            else if (choice == 5) {
                System.out.println("--- All Books ---");
                for (Book b : books) {
                    System.out.println("ID: " + b.id + "   Name: " + b.name + "   Available: " + b.available);
                }
            }

            else if (choice == 6) {
                System.out.println("Thank You!");
                break;
            }

            else {
                System.out.println("Invalid Choice");
            }
        }

        sc.close();
    }
}
