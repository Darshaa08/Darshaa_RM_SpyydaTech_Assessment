public class CalculatorWithHistory {

    static String[] history = new String[10];
    static int index = 0;

    public static void main(String[] args) {

        double a = 10, b = 5;
        double r1 = add(a, b);
        store("10 + 5 = " + r1);

        double r2 = sub(a, b);
        store("10 - 5 = " + r2);

        double r3 = mul(a, b);
        store("10 * 5 = " + r3);

        double r4 = div(a, b);
        store("10 / 5 = " + r4);

        get_history();
    }

    public static double add(double x, double y) {
        return x + y;
    }

    public static double sub(double x, double y) {
        return x - y;
    }

    public static double mul(double x, double y) {
        return x * y;
    }

    public static double div(double x, double y) {
        if (y == 0) return 0;
        return x / y;
    }

    public static void store(String s) {
        history[index] = s;
        index++;
    }

    public static void get_history() {
        for (int i = 0; i < index; i++) {
            System.out.println(history[i]);
        }
    }
}
